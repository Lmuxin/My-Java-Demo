package faceattendsystem.entity;

import java.io.Serializable;
import java.sql.Date;

public class Flowsheet implements Serializable {
	private Date logdate; // 操作日期
	private String logtime; // 操作时间
	private Employee employee;// 操作员工
	private String clientdatetime;// 客户机时间
	private String logip;// 操作ip
	private int rtn;// 运行时间
	private String message;// 识别反馈
	private float similarity;// 识别相似度
	private String requestid;// 请求id
	private String result;// 结果是否有效
	private String picmd5;// 存识别的图片

	public Flowsheet() {
		super();
	}

	public Flowsheet(Date logdate, String logtime, Employee employee, String clientdatetime, String logip, int rtn,
			String message, float similarity, String requestid, String result, String picmd5) {
		super();
		this.logdate = logdate;
		this.logtime = logtime;
		this.employee = employee;
		this.clientdatetime = clientdatetime;
		this.logip = logip;
		this.rtn = rtn;
		this.message = message;
		this.similarity = similarity;
		this.requestid = requestid;
		this.result = result;
		this.picmd5 = picmd5;
	}

	public Date getLogdate() {
		return logdate;
	}

	public void setLogdate(Date logdate) {
		this.logdate = logdate;
	}

	public String getLogtime() {
		return logtime;
	}

	public void setLogtime(String logtime) {
		this.logtime = logtime;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public String getClientdatetime() {
		return clientdatetime;
	}

	public void setClientdatetime(String clientdatetime) {
		this.clientdatetime = clientdatetime;
	}

	public String getLogip() {
		return logip;
	}

	public void setLogip(String logip) {
		this.logip = logip;
	}

	public int getRtn() {
		return rtn;
	}

	public void setRtn(int rtn) {
		this.rtn = rtn;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public float getSimilarity() {
		return similarity;
	}

	public void setSimilarity(float similarity) {
		this.similarity = similarity;
	}

	public String getRequestid() {
		return requestid;
	}

	public void setRequestid(String requestid) {
		this.requestid = requestid;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getPicmd5() {
		return picmd5;
	}

	public void setPicmd5(String picmd5) {
		this.picmd5 = picmd5;
	}

	@Override
	public String toString() {
		return "Flowsheet [logdate=" + logdate + ", logtime=" + logtime + ", employee=" + employee + ", clientdatetime="
				+ clientdatetime + ", logip=" + logip + ", rtn=" + rtn + ", message=" + message + ", similarity="
				+ similarity + ", requestid=" + requestid + ", result=" + result + ", picmd5=" + picmd5 + "]";
	}

}
