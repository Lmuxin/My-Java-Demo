package faceattendsystem.entity;

import java.io.Serializable;
import java.sql.Date;

public class Specday implements Serializable {
	private Date specbdate;// 开始日期
	private Date specedate;// 结束日期
	private String daytype;// 日期类型:H、W
	private String specname;// 节假名

	public Specday() {
		super();
	}

	public Specday(Date specbdate, Date specedate, String daytype, String specname) {
		super();
		this.specbdate = specbdate;
		this.specedate = specedate;
		this.daytype = daytype;
		this.specname = specname;
	}

	public Date getSpecbdate() {
		return specbdate;
	}

	public void setSpecbdate(Date specbdate) {
		this.specbdate = specbdate;
	}

	public Date getSpecedate() {
		return specedate;
	}

	public void setSpecedate(Date specedate) {
		this.specedate = specedate;
	}

	public String getDaytype() {
		return daytype;
	}

	public void setDaytype(String daytype) {
		this.daytype = daytype;
	}

	public String getSpecname() {
		return specname;
	}

	public void setSpecname(String specname) {
		this.specname = specname;
	}

	@Override
	public String toString() {
		return "Specday [specbdate=" + specbdate + ", specedate=" + specedate + ", daytype=" + daytype + ", specname="
				+ specname + "]";
	}

}
