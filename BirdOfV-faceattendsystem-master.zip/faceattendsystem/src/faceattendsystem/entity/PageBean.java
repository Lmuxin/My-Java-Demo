package faceattendsystem.entity;

import java.io.Serializable;
import java.util.List;

public class PageBean<T> implements Serializable {
	private int pc;// 当前页
	private int tr;// 总记录数
	private int ps;// 每页记录
	private List<T> beanList; // 当前页的记录
	private String url; // 它就是url后的条件

	public int getTp(){//获取总页数
		int tp = tr/ps;
		return tr%ps==0?tp:tp+1;
		//return tr%ps==0?tr/ps:tr/ps+1;
	}
	
	public int getPc() {
		return pc;
	}

	public void setPc(int pc) {
		this.pc = pc;
	}

	public int getTr() {
		return tr;
	}

	public void setTr(int tr) {
		this.tr = tr;
	}

	public int getPs() {
		return ps;
	}

	public void setPs(int ps) {
		this.ps = ps;
	}

	public List<T> getBeanList() {
		return beanList;
	}

	public void setBeanList(List<T> beanList) {
		this.beanList = beanList;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
