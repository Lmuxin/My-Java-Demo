package faceattendsystem.entity;

import java.io.Serializable;
import java.sql.Date;

public class Runresult implements Serializable {
	private Date rundate;//统计异常的运行日期
	private String runstate;//统计异常的运行结果

	public Runresult() {
		super();
	}

	public Runresult(Date rundate, String runstate) {
		super();
		this.rundate = rundate;
		this.runstate = runstate;
	}

	public Date getRundate() {
		return rundate;
	}

	public void setRundate(Date rundate) {
		this.rundate = rundate;
	}

	public String getRunstate() {
		return runstate;
	}

	public void setRunstate(String runstate) {
		this.runstate = runstate;
	}

	@Override
	public String toString() {
		return "Runresult [rundate=" + rundate + ", runstate=" + runstate + "]";
	}

}
