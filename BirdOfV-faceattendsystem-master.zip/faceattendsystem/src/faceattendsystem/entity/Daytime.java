package faceattendsystem.entity;

import java.io.Serializable;
import java.sql.Date;

public class Daytime implements Serializable {
	private Mechanism mechanism;// 所属机构
	private String daytype;// 作息类型：H、W
	private Date daybdate; // 开始日期
	private Date dayedate; // 结束日期
	private String begintime; // 开始时间
	private String endtime; // 结束时间

	public Daytime() {
		super();
	}

	public Daytime(Mechanism mechanism, String daytype, Date daybdate, Date dayedate, String begintime,
			String endtime) {
		super();
		this.mechanism = mechanism;
		this.daytype = daytype;
		this.daybdate = daybdate;
		this.dayedate = dayedate;
		this.begintime = begintime;
		this.endtime = endtime;
	}

	public Mechanism getMechanism() {
		return mechanism;
	}

	public void setMechanism(Mechanism mechanism) {
		this.mechanism = mechanism;
	}

	public String getDaytype() {
		return daytype;
	}

	public void setDaytype(String daytype) {
		this.daytype = daytype;
	}

	public Date getDaybdate() {
		return daybdate;
	}

	public void setDaybdate(Date daybdate) {
		this.daybdate = daybdate;
	}

	public Date getDayedate() {
		return dayedate;
	}

	public void setDayedate(Date dayedate) {
		this.dayedate = dayedate;
	}

	public String getBegintime() {
		return begintime;
	}

	public void setBegintime(String begintime) {
		this.begintime = begintime;
	}

	public String getEndtime() {
		return endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	@Override
	public String toString() {
		return "Daytime [mechanism=" + mechanism + ", daytype=" + daytype + ", daybdate=" + daybdate + ", dayedate="
				+ dayedate + ", begintime=" + begintime + ", endtime=" + endtime + "]";
	}

}
