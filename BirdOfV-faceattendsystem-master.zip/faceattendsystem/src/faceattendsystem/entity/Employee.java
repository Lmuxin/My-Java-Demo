package faceattendsystem.entity;

import java.io.Serializable;

public class Employee implements Serializable {
	private Mechanism mechanism;// 所属机构
	private String empid; // 员工号
	private String name; // 姓名
	private String password;// 密码
	private String idnumber;// 身份证号
	private String picmd5; // 头像
	private String power; // 权限
	private String state; // 状态

	public Employee() {
		super();
	}

	public Employee(Mechanism mechanism, String empid, String password, String name, String idnumber, String power,
			String picmd5, String state) {
		super();
		this.mechanism = mechanism;
		this.empid = empid;
		this.password = password;
		this.name = name;
		this.idnumber = idnumber;
		this.power = power;
		this.picmd5 = picmd5;
		this.state = state;
	}

	public Mechanism getMechanism() {
		return mechanism;
	}

	public void setMechanism(Mechanism mechanism) {
		this.mechanism = mechanism;
	}

	public String getEmpid() {
		return empid;
	}

	public void setEmpid(String empid) {
		this.empid = empid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIdnumber() {
		return idnumber;
	}

	public void setIdnumber(String idnumber) {
		this.idnumber = idnumber;
	}

	public String getPower() {
		return power;
	}

	public void setPower(String power) {
		this.power = power;
	}

	public String getPicmd5() {
		return picmd5;
	}

	public void setPicmd5(String picmd5) {
		this.picmd5 = picmd5;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "Employee [mechanism=" + mechanism + ", empid=" + empid + ", name=" + name + ", password=" + password
				+ ", idnumber=" + idnumber + ", picmd5=" + picmd5 + ", power=" + power + ", state=" + state + "]";
	}

}
