package faceattendsystem.entity;

import java.io.Serializable;
import java.sql.Date;

public class Errorsheet implements Serializable {
	private Mechanism mechanism;// 统计机构
	private Employee employee;// 统计员工
	private Date tjdate;// 统计日期
	private String tjtype;// 日期类型,工作or休息
	private String errtype;// 错误情况0:签到正常/签退正常；1:未签到/未签退；2:迟到/早退
	private String tjmsg;// 异常描述

	public Errorsheet() {
		super();
	}

	public Errorsheet(Mechanism mechanism, Employee employee, Date tjdate, String tjtype, String errtype, String tjmsg) {
		super();
		this.mechanism = mechanism;
		this.employee = employee;
		this.tjdate = tjdate;
		this.tjtype = tjtype;
		this.errtype = errtype;
		this.tjmsg = tjmsg;
	}

	public Mechanism getMechanism() {
		return mechanism;
	}

	public void setMechanism(Mechanism mechanism) {
		this.mechanism = mechanism;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Date getTjdate() {
		return tjdate;
	}

	public void setTjdate(Date tjdate) {
		this.tjdate = tjdate;
	}

	public String getTjtype() {
		return tjtype;
	}

	public void setTjtype(String tjtype) {
		this.tjtype = tjtype;
	}

	public String getErrtype() {
		return errtype;
	}

	public void setErrtype(String errtype) {
		this.errtype = errtype;
	}

	public String getTjmsg() {
		return tjmsg;
	}

	public void setTjmsg(String tjmsg) {
		this.tjmsg = tjmsg;
	}

	@Override
	public String toString() {
		return "Error [mechanism=" + mechanism + ", employee=" + employee + ", tjdate=" + tjdate + ", tjtype=" + tjtype
				+ ", errtype=" + errtype + ", tjmsg=" + tjmsg + "]";
	}

}
