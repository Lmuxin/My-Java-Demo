package faceattendsystem.entity;

import java.io.Serializable;

public class Mechanism implements Serializable {
	private String mechid;// 机构号
	private String mechname;// 机构名
	private String mechip;// 机构ip
	private float minsimilarity;// 最小相似度
	// private Date mechdate;// 机构日期

	public Mechanism() {
		super();
	}

	public Mechanism(String mechid, String mechname, String mechip, float minsimilarity) {
		super();
		this.mechid = mechid;
		this.mechname = mechname;
		this.mechip = mechip;
		this.minsimilarity = minsimilarity;
	}

	public String getMechid() {
		return mechid;
	}

	public void setMechid(String mechid) {
		this.mechid = mechid;
	}

	public String getMechname() {
		return mechname;
	}

	public void setMechname(String mechname) {
		this.mechname = mechname;
	}

	public String getMechip() {
		return mechip;
	}

	public void setMechip(String mechip) {
		this.mechip = mechip;
	}

	public float getMinsimilarity() {
		return minsimilarity;
	}

	public void setMinsimilarity(float minsimilarity) {
		this.minsimilarity = minsimilarity;
	}

	@Override
	public String toString() {
		return "Mechanism [mechid=" + mechid + ", mechname=" + mechname + ", mechip=" + mechip + ", minsimilarity="
				+ minsimilarity + "]";
	}

}
