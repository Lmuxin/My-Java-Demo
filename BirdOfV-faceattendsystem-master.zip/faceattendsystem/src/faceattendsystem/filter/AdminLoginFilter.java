package faceattendsystem.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import faceattendsystem.entity.Employee;


public class AdminLoginFilter implements Filter {

	@Override
	public void destroy() {}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException {
		/*
		 * 1.从session中获取用户信息 2.判断如题session中存在用户信息，放行！ 3.否则，保存错误信息，转发到login.jsp显示
		 */
		HttpServletRequest httpRequest = (HttpServletRequest) req;
		HttpServletResponse httpResponse = (HttpServletResponse) resp;
		
		Employee employee = (Employee) httpRequest.getSession().getAttribute("employee");
		if(employee != null){
			if(employee.getPower().equals("0")){
				chain.doFilter(req, resp);
			}else{
				httpResponse.sendRedirect("/FaceAttendSystem/jsps/login.jsp");
			}
		}else{
			httpRequest.getRequestDispatcher("/jsps/login.jsp").forward(httpRequest, resp);
		}
	}

	@Override
	public void init(FilterConfig config) throws ServletException {}
}
