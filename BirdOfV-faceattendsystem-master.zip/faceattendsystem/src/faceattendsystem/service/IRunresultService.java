package faceattendsystem.service;

import java.sql.Date;
import java.util.List;

import faceattendsystem.entity.Runresult;


public interface IRunresultService {
	// 查询指定日期的状态
	public abstract String queryByNowdate(Date nowdate);

	// 添加记录
	public abstract int add(Runresult runresult);

	// 修改记录
	public abstract int update(Runresult runresult);

	// 查询时间段内的成功日期
	public abstract List<Date> queryByDatearea(Date nowdate, Date predate);

	// 查询时间段内的成功日期
	public abstract int getSuccessDate(Date nowdate, Date predate);
	
	//查找当前最小的日期
	public abstract Date getMinDate();	
}
