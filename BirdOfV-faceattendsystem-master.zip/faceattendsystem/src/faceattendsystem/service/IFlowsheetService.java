package faceattendsystem.service;

import java.sql.Date;
import java.util.List;

import faceattendsystem.entity.Employee;
import faceattendsystem.entity.Flowsheet;
import faceattendsystem.entity.PageBean;

public interface IFlowsheetService {
	public abstract List<Flowsheet> query(Date date, String empid);
	
	//获取员工的最早日期或全部人的最早日期
	public abstract Date getMindate(Employee employee);

	//获取流水
	public abstract PageBean<Flowsheet> query(String empid, String bdate, String edate, int pc, int ps);

	//导出excel
	public abstract PageBean<Flowsheet> queryAll(String empid, String bdate, String edate);
}
