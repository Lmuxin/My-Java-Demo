package faceattendsystem.service;

import java.util.List;

import faceattendsystem.entity.Employee;
import faceattendsystem.entity.PageBean;


public interface IEmployeeService {
	//增
	public abstract int add(Employee employee);
	
	//删
	public abstract int delete(String empid);
	
	//改
	public abstract int update(Employee employee);
	
	//修改密码
	public abstract int updatePw(String empid,String npw);
	
	//查某个员工
	public Employee queryByEmpid(String empid);
	
	//按机构查询
	public abstract List<Employee> queryByMechid(String mechid);
	
	//查某个机构的员工
	public abstract PageBean<Employee> queryByMechid(String mechid,int pc,int ps);
	
	//模糊查询
	public abstract PageBean<Employee> query(Employee employee,int pc,int ps);
	
	//查所有员工
	public abstract List<Employee> queryAll();

	//工号是否重复
	public abstract boolean isRepeatEmpid(String empid);	
	
	//查询员工
	public abstract Employee isEmployee(String empid);

	//身份证号是否重复
	public abstract Employee isRepeatIdnumber(String idnumber);	
}
