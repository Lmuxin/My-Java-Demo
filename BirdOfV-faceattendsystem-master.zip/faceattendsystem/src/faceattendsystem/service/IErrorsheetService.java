package faceattendsystem.service;

import java.util.List;

import faceattendsystem.entity.Errorsheet;
import faceattendsystem.entity.PageBean;

public interface IErrorsheetService {
	// 模糊查询
	public abstract PageBean<Errorsheet> query(Errorsheet errorsheet,String bdate,String edate, int pc, int ps);

	//添加记录
	public abstract int add(Errorsheet errorsheet);

	public abstract List<Errorsheet> queryAll();
	
	//查询所有匹配记录
	public abstract PageBean<Errorsheet> queryAll(Errorsheet errorsheet, String bdate, String edate);
}
