package faceattendsystem.service;

import java.util.List;

import faceattendsystem.entity.Mechanism;
import faceattendsystem.entity.PageBean;

public interface IMechanismService {
	// 增
	public abstract int add(Mechanism mechanism);

	// 删单个
	public abstract int delete(String mechid);

	// 删全部
	public abstract int delete();

	// 改
	public abstract int update(Mechanism mechanism);

	// 查某个机构名
	public abstract Mechanism queryByMechname(String mechname);

	// 查询所有机构
	public abstract List<Mechanism> queryAll();

	// 模糊查询
	public abstract PageBean<Mechanism> query(Mechanism mechanism, int pc, int ps);

	//查询机构号
	public abstract Mechanism queryByMechid(String mechid);
}
