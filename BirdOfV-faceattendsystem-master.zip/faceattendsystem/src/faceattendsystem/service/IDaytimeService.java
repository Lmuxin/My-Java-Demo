package faceattendsystem.service;

import java.sql.Date;

import faceattendsystem.entity.Daytime;
import faceattendsystem.entity.PageBean;

public interface IDaytimeService {
	// 增
	public abstract int add(Daytime daytime);

	// 改
	public abstract int update(Daytime daytime);

	// 查某个机构的节假日
	public abstract PageBean<Daytime> queryByMechid(String mechid, int pc, int ps);

	// 是否重复
	public abstract int isRepeatDate(Daytime daytime);

	//获取机构作息时间
	public abstract Daytime queryByMechid(String mechid, Date nowdate);

	//模糊查询
	public abstract PageBean<Daytime> query(Daytime daytime, int pc, int ps);
}
