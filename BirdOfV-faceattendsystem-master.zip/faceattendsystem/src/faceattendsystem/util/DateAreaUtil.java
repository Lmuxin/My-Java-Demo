package faceattendsystem.util;

import java.sql.Date;
import java.util.Calendar;

public class DateAreaUtil {
	public static int daynum = 100;// 最多100天

	//获取实际天数
	public static int getDatedata(Date mindate,int daynum) {
		// 管理员不是每天都登录，所以要选择当前日期和之前的一段时间，判断一段时间。
		//Date nowdate = new Date(new java.util.Date().getTime());
		Calendar calendar = Calendar.getInstance();
		int daynum1 = calendar.get(Calendar.DAY_OF_YEAR);
		int nowyear = calendar.YEAR;

		calendar.add(Calendar.DATE, -daynum);
		int daynum2 = calendar.get(Calendar.DAY_OF_YEAR);

		// 100天前的日期
		Date predate = new Date(calendar.getTime().getTime());
		//System.out.println(mindate + " " + predate);

		// 若最小的日期比100天前早，则取最小日期
		if (mindate.compareTo(predate) > 0) {
			predate = mindate;
			calendar.setTime(predate);
			daynum2 = calendar.get(Calendar.DAY_OF_YEAR);
		}

		// 获取实际的相差多少天
		while (nowyear > calendar.YEAR) {
			daynum1 += Calendar.DAY_OF_YEAR;
			calendar.add(Calendar.DATE, 1);
		}
		
		daynum = daynum1 - daynum2;
		return daynum;
	}
}
