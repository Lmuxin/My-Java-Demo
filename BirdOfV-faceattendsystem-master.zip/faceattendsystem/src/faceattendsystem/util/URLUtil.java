package faceattendsystem.util;

import javax.servlet.http.HttpServletRequest;

public class URLUtil {
	public static int ps = 12;//每页最多12条记录
	
	// 获取当前页码
	public static int getPc(HttpServletRequest req) {
		String pc = req.getParameter("pc");
		if (pc == null || pc.trim().isEmpty()) {
			return 1;
		}
		return Integer.parseInt(pc);
	}

	// 获取链接地址
	public static String getUrl(HttpServletRequest req) {
		String contextPath = req.getContextPath();// 获取项目名
		String servletPath = req.getServletPath();// 获取servletPath，即/StudentServlet
		String queryString = req.getQueryString();// 获取问号之后的参数部分

		// 判断参数部分中是否包含pc这个参数，如果包含，需要截取下去，不要这一部分。
		if (queryString == null) {
			queryString = "pc=1";
		} else if (queryString.contains("&pc=")) {
			int index = queryString.lastIndexOf("&pc=");
			queryString = queryString.substring(0, index);
		} else if (queryString.contains("?pc=")) {
			int index = queryString.lastIndexOf("?pc=");
			queryString = queryString.substring(0, index);
		}
		
		return contextPath + servletPath + "?" + queryString;
	}
}
