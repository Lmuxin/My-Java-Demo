package faceattendsystem.dao;

import java.sql.Date;
import java.util.List;

import faceattendsystem.entity.Employee;
import faceattendsystem.entity.Flowsheet;
import faceattendsystem.entity.PageBean;


public interface IFlowsheetDao {
	//获取某个日期某员工的记录
	public abstract List<Flowsheet> query(Date date, String empid);

	//获取最小日期
	public abstract Date getMindate(Employee employee);

	//获取流水
	public abstract PageBean<Flowsheet> query(String empid, String bdate, String edate, int pc, int ps);

	//导出excel
	public abstract PageBean<Flowsheet> queryAll(String empid, String bdate, String edate);
}
