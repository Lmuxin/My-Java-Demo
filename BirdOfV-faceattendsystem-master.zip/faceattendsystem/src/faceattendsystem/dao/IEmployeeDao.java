package faceattendsystem.dao;

import java.util.List;

import faceattendsystem.entity.Employee;
import faceattendsystem.entity.PageBean;


public interface IEmployeeDao {
	// 增
	public abstract int add(Employee employee);

	// 删
	public abstract int delete(String empid);

	// 改
	public abstract int update(Employee employee);

	// 修改密码
	public abstract int updatePw(String empid, String npw);

	// 查某个员工
	public abstract Employee queryByEmpid(String empid);

	// 查机构员工
	public abstract List<Employee> queryByMechid(String mechid);

	// 查某个机构的员工分页
	public abstract PageBean<Employee> queryByMechid(String mechid, int pc, int ps);

	// 模糊查询分页
	public abstract PageBean<Employee> query(Employee employee, int pc, int ps);

	// 查所有员工
	public abstract List<Employee> queryAll();

	// 查身份证号是否存在
	public abstract Employee queryByIdnumber(String idnumber);
}
