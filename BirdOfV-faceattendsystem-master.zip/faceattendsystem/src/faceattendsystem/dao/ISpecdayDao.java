package faceattendsystem.dao;

import java.sql.Date;

import faceattendsystem.entity.PageBean;
import faceattendsystem.entity.Specday;

public interface ISpecdayDao {
	// 增
	public abstract int add(Specday specday);

	// 查所有节假日
	public abstract PageBean<Specday> queryAll(int pc, int ps);

	// 模糊查询
	public abstract PageBean<Specday> query(Specday specday, int pc, int ps);

	// 查是否有重复日期
	public abstract int isRepeatDate(Date bdate);
	
	//获取日期类型
	public abstract String queryByNowdate(Date nowdate);
}
