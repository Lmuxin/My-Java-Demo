package faceattendsystem.serviceImpl;

import java.sql.Date;

import faceattendsystem.dao.IMechanismDao;
import faceattendsystem.dao.ISpecdayDao;
import faceattendsystem.daoImpl.MechanismDaoImpl;
import faceattendsystem.daoImpl.SpecdayDaoImpl;
import faceattendsystem.entity.PageBean;
import faceattendsystem.entity.Specday;
import faceattendsystem.service.ISpecdayService;



public class SpecdayServiceImpl implements ISpecdayService {
	ISpecdayDao specdayDao = new SpecdayDaoImpl();
	IMechanismDao mechanismDao = new MechanismDaoImpl();
	
	@Override
	public int add(Specday specday) {
		return specdayDao.add(specday);
	}

	@Override
	public int isRepeatDate(Date bdate) {
		return specdayDao.isRepeatDate(bdate);
	}

	@Override
	public String queryByNowdate(Date nowdate) {
		return specdayDao.queryByNowdate(nowdate);
	}

	@Override
	public PageBean<Specday> queryAll(int pc, int ps) {
		return specdayDao.queryAll(pc, ps);
	}
	
	@Override
	public PageBean<Specday> query(Specday specday, int pc, int ps) {
		return specdayDao.query(specday,pc, ps);
	}

}
