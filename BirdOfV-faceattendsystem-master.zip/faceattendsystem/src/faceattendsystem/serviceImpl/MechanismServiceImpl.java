package faceattendsystem.serviceImpl;

import java.util.List;

import faceattendsystem.dao.IMechanismDao;
import faceattendsystem.daoImpl.MechanismDaoImpl;
import faceattendsystem.entity.Mechanism;
import faceattendsystem.entity.PageBean;
import faceattendsystem.service.IMechanismService;



public class MechanismServiceImpl implements IMechanismService {
	private IMechanismDao mechanismDao = new MechanismDaoImpl();
	
	@Override
	public int add(Mechanism mechanism) {
		return mechanismDao.add(mechanism);
	}

	@Override
	public int delete(String mechid) {
		return mechanismDao.delete(mechid);
	}

	@Override
	public int delete() {
		return mechanismDao.delete();
	}
	
	@Override
	public int update(Mechanism mechanism) {
		return mechanismDao.update(mechanism);
	}

	@Override
	public Mechanism queryByMechname(String mechname) {
		return mechanismDao.queryByMechname(mechname);
	}
	
	@Override
	public PageBean<Mechanism> query(Mechanism mechanism,int pc, int ps) {
		return mechanismDao.query(mechanism, pc, ps);
	}

	@Override
	public List<Mechanism> queryAll() {
		return mechanismDao.queryAll();
	}

	@Override
	public Mechanism queryByMechid(String mechid) {
		return mechanismDao.queryByMechid(mechid);
	}

}
