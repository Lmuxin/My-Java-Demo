package faceattendsystem.serviceImpl;

import java.sql.Date;
import java.util.List;

import faceattendsystem.dao.IEmployeeDao;
import faceattendsystem.dao.IFlowsheetDao;
import faceattendsystem.daoImpl.EmployeeDaoImpl;
import faceattendsystem.daoImpl.FlowsheetDaoImpl;
import faceattendsystem.entity.Employee;
import faceattendsystem.entity.Flowsheet;
import faceattendsystem.entity.PageBean;
import faceattendsystem.service.IFlowsheetService;



public class FlowsheetServiceImpl implements IFlowsheetService {
	IFlowsheetDao flowsheetDao = new FlowsheetDaoImpl();
	IEmployeeDao employeeDao = new EmployeeDaoImpl();

	@Override
	public List<Flowsheet> query(Date date, String empid) {
		return flowsheetDao.query(date,empid);
	}

	@Override
	public Date getMindate(Employee employee) {
		return flowsheetDao.getMindate(employee);
	}

	@Override
	public PageBean<Flowsheet> query(String empid, String bdate, String edate, int pc, int ps) {
		PageBean<Flowsheet> pb = flowsheetDao.query(empid,bdate,edate,pc,ps);
		List<Flowsheet> flowsheetList = pb.getBeanList();
		for(Flowsheet fs:flowsheetList){
			fs.setEmployee(employeeDao.queryByEmpid(fs.getEmployee().getEmpid()));
			fs.setLogtime(getRealTime(fs.getLogtime()));
			fs.setClientdatetime(getDatetime(fs.getClientdatetime()));
			//fs.setSimilarity(getExactValue(fs.getSimilarity()));
		}
		return pb;
	}

	@Override
	public PageBean<Flowsheet> queryAll(String empid, String bdate, String edate) {
		PageBean<Flowsheet> pb = flowsheetDao.queryAll(empid,bdate,edate);
		List<Flowsheet> flowsheetList = pb.getBeanList();
		
		for(Flowsheet fs:flowsheetList){
			fs.setEmployee(employeeDao.queryByEmpid(fs.getEmployee().getEmpid()));
			fs.setLogtime(getRealTime(fs.getLogtime()));
			fs.setClientdatetime(getDatetime(fs.getClientdatetime()));
		}
		return pb;
	}
	
/*	private float getExactValue(float similarity) {
		return (Math.round(similarity*100)/100);
	}*/
	
	private String getDatetime(String datetime) {
		String date = datetime.substring(0,8);
		date = date.substring(0,4)+"-"+date.substring(4,6)+"-"+date.substring(6);
		String time = datetime.substring(8);
		time = getRealTime(time);
		datetime = date+" "+time;
		return datetime;
	}

	private String getRealTime(String time){
		while(time.length()<6){
			time = "0"+time;
		}
		time = time.substring(0,2)+":"+time.substring(2,4)+":"+time.substring(4);
		return time;
	}
}
