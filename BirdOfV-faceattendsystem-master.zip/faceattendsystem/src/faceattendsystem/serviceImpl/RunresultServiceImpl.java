package faceattendsystem.serviceImpl;

import java.sql.Date;
import java.util.List;

import faceattendsystem.dao.IRunresultDao;
import faceattendsystem.daoImpl.RunresultDaoImpl;
import faceattendsystem.entity.Runresult;
import faceattendsystem.service.IRunresultService;



public class RunresultServiceImpl implements IRunresultService {
	IRunresultDao runresultDao = new RunresultDaoImpl();

	@Override
	public String queryByNowdate(Date nowdate) {
		return runresultDao.queryByNowdate(nowdate);
	}

	@Override
	public int add(Runresult runresult) {
		return runresultDao.add(runresult);
	}

	@Override
	public int update(Runresult runresult) {
		return runresultDao.update(runresult);
	}

	@Override
	public List<Date> queryByDatearea(Date nowdate, Date predate) {
		return runresultDao.queryByDatearea(nowdate,predate);
	}
	
	@Override
	public int getSuccessDate(Date nowdate, Date predate) {
		return runresultDao.getSuccessDate(nowdate,predate);
	}

	@Override
	public Date getMinDate() {
		return runresultDao.getMinDate();
	}
}
