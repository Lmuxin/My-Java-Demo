package faceattendsystem.serviceImpl;

import java.util.List;

import faceattendsystem.dao.IEmployeeDao;
import faceattendsystem.dao.IErrorsheetDao;
import faceattendsystem.dao.IMechanismDao;
import faceattendsystem.daoImpl.EmployeeDaoImpl;
import faceattendsystem.daoImpl.ErrorsheetDaoImpl;
import faceattendsystem.daoImpl.MechanismDaoImpl;
import faceattendsystem.entity.Errorsheet;
import faceattendsystem.entity.PageBean;
import faceattendsystem.service.IErrorsheetService;



public class ErrorsheetServiceImpl implements IErrorsheetService {
	IErrorsheetDao errorsheetDao = new ErrorsheetDaoImpl();
	IMechanismDao mechanismDao = new MechanismDaoImpl();
	IEmployeeDao employeeDao = new EmployeeDaoImpl();

	@Override
	public PageBean<Errorsheet> query(Errorsheet errorsheet, String bdate, String edate, int pc, int ps) {
		PageBean<Errorsheet> pb = errorsheetDao.query(errorsheet, bdate, edate, pc, ps);

		List<Errorsheet> errorsheetList = pb.getBeanList();
		for (Errorsheet e : errorsheetList) {
			e.setMechanism(mechanismDao.queryByMechid(e.getMechanism().getMechid()));
			e.setEmployee(employeeDao.queryByEmpid(e.getEmployee().getEmpid()));
		}

		pb.setBeanList(errorsheetList);
		return pb;
	}

	@Override
	public int add(Errorsheet errorsheet) {
		return errorsheetDao.add(errorsheet);
	}

	@Override
	public List<Errorsheet> queryAll() {
		return errorsheetDao.queryAll();
	}

	@Override
	public PageBean<Errorsheet> queryAll(Errorsheet errorsheet, String bdate, String edate) {
		PageBean<Errorsheet> pb = errorsheetDao.queryAll(errorsheet, bdate, edate);

		List<Errorsheet> errorsheetList = pb.getBeanList();
		for (Errorsheet e : errorsheetList) {
			e.setMechanism(mechanismDao.queryByMechid(e.getMechanism().getMechid()));
			e.setEmployee(employeeDao.queryByEmpid(e.getEmployee().getEmpid()));
		}

		pb.setBeanList(errorsheetList);
		return pb;
	}
}
