package faceattendsystem.serviceImpl;

import java.util.List;

import faceattendsystem.dao.IEmployeeDao;
import faceattendsystem.dao.IMechanismDao;
import faceattendsystem.daoImpl.EmployeeDaoImpl;
import faceattendsystem.daoImpl.MechanismDaoImpl;
import faceattendsystem.entity.Employee;
import faceattendsystem.entity.Mechanism;
import faceattendsystem.entity.PageBean;
import faceattendsystem.service.IEmployeeService;



public class EmployeeServiceImpl implements IEmployeeService {
	private IEmployeeDao employeeDao = new EmployeeDaoImpl();
	private IMechanismDao  mechanismDao = new MechanismDaoImpl();
	
	@Override
	public int add(Employee employee) {
		return employeeDao.add(employee);
	}

	@Override
	public int delete(String empid) {
		return employeeDao.delete(empid);
	}

	@Override
	public int update(Employee employee) {
		return employeeDao.update(employee);
	}

	@Override
	public int updatePw(String empid,String npw) {
		return employeeDao.updatePw(empid,npw);
	}

	@Override
	public Employee queryByEmpid(String empid) {
		Employee employee = employeeDao.queryByEmpid(empid);
		employee.setMechanism(mechanismDao.queryByMechid(employee.getMechanism().getMechid()));
		return employee;
	}

	@Override
	public PageBean<Employee> queryByMechid(String mechid, int pc, int ps) {
		return employeeDao.queryByMechid(mechid, pc, ps);
	}

	@Override
	public List<Employee> queryAll() {
		return employeeDao.queryAll();
	}

	@Override
	public PageBean<Employee> query(Employee employee, int pc, int ps) {
		PageBean<Employee> pb = employeeDao.query(employee,pc,ps);
		
		List<Employee> employeeList = pb.getBeanList();
		for(Employee e : employeeList){
			e.setMechanism(mechanismDao.queryByMechid(e.getMechanism().getMechid()));
		}
		
		pb.setBeanList(employeeList);
		return pb;
	}

	@Override
	public List<Employee> queryByMechid(String mechid) {
		List<Employee> employeeList = employeeDao.queryByMechid(mechid);
		for(Employee emp : employeeList){
			Mechanism mechanism = mechanismDao.queryByMechid(emp.getMechanism().getMechid());
			emp.setMechanism(mechanism);
		}
		return employeeList;
	}

	@Override
	public boolean isRepeatEmpid(String empid) {
		Employee employee = employeeDao.queryByEmpid(empid);
		return employee!=null?true:false;
	}

	@Override
	public Employee isEmployee(String empid) {
		Employee employee = employeeDao.queryByEmpid(empid);
		if(employee!=null){
			employee.setMechanism(mechanismDao.queryByMechid(employee.getMechanism().getMechid()));
		}
		return employee;
	}

	@Override
	public Employee isRepeatIdnumber(String idnumber) {
		return employeeDao.queryByIdnumber(idnumber);
	}
}
