package faceattendsystem.serviceImpl;

import java.sql.Date;
import java.util.List;

import faceattendsystem.dao.IDaytimeDao;
import faceattendsystem.dao.IMechanismDao;
import faceattendsystem.daoImpl.DaytimeDaoImpl;
import faceattendsystem.daoImpl.MechanismDaoImpl;
import faceattendsystem.entity.Daytime;
import faceattendsystem.entity.PageBean;
import faceattendsystem.service.IDaytimeService;



public class DaytimeServiceImpl implements IDaytimeService {
	private IDaytimeDao daytimeDao = new DaytimeDaoImpl();
	private IMechanismDao mechanismDao = new MechanismDaoImpl();
	
	@Override
	public int add(Daytime daytime) {
		return daytimeDao.add(daytime);
	}

	@Override
	public int update(Daytime daytime) {
		return daytimeDao.update(daytime);
	}
	
	@Override
	public PageBean<Daytime> queryByMechid(String mechid, int pc, int ps) {
		PageBean<Daytime> pb =daytimeDao.queryByMechid(mechid, pc, ps);
		List<Daytime> daytimeList = pb.getBeanList();
		for(Daytime daytime:daytimeList){
			daytime.setMechanism(mechanismDao.queryByMechid(mechid));
			daytime.setBegintime(getRealTime(daytime.getBegintime()));
			daytime.setEndtime(getRealTime(daytime.getEndtime()));
		}
		return pb;
	}
	
	private String getRealTime(String time){
		while(time.length()<6){
			time = "0"+time;
		}
		time = time.substring(0,2)+":"+time.substring(2,4)+":"+time.substring(4,6);
		return time;
	}

	@Override
	public int isRepeatDate(Daytime daytime) {
		return daytimeDao.isRepeatDate(daytime);
	}

	@Override
	public Daytime queryByMechid(String mechid, Date nowdate) {
		Daytime daytime = daytimeDao.queryByMechid(mechid, nowdate);
		daytime.setMechanism(mechanismDao.queryByMechid(mechid));
		return daytime;
	}

	@Override
	public PageBean<Daytime> query(Daytime daytime, int pc, int ps) {
		PageBean<Daytime> pb =daytimeDao.query(daytime, pc, ps);
		List<Daytime> daytimeList = pb.getBeanList();
		for(Daytime d:daytimeList){
			d.setMechanism(mechanismDao.queryByMechid(d.getMechanism().getMechid()));
			d.setBegintime(getRealTime(d.getBegintime()));
			d.setEndtime(getRealTime(d.getEndtime()));
		}
		return pb;
	}
}
