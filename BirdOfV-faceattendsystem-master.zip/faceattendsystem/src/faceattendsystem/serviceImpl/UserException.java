package faceattendsystem.serviceImpl;

/**
 * 抛出用户异常信息
 * 
 * @author Leo
 *
 */
public class UserException extends Exception {

	public UserException() {
		super();
	}

	public UserException(String message) {
		super(message);
	}
}
