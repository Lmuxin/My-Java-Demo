package faceattendsystem.daoImpl;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import faceattendsystem.dao.IRunresultDao;
import faceattendsystem.entity.Runresult;
import faceattendsystem.util.JDBCTemplate;
import faceattendsystem.util.JDBCTemplate.PreparedStatementSetter;
import faceattendsystem.util.JDBCTemplate.ResultSetCallBack;



public class RunresultDaoImpl implements IRunresultDao {

	@Override
	public String queryByNowdate(Date nowdate) {
		String sql = "select runstate from runresult where rundate=?";
		
		String runstate = JDBCTemplate.singleQuery(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement pstmt) throws SQLException {
				pstmt.setDate(1, nowdate);
			}
		}, new ResultSetCallBack<String>() {
			@Override
			public String processRs(ResultSet rs) throws SQLException {
				return rs.getString(1);
			}
		});
		
		return runstate;
	}

	@Override
	public int add(Runresult runresult) {
		String sql = "insert into runresult values(?,?)";
		
		int result = JDBCTemplate.update(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement pstmt) throws SQLException {
				pstmt.setDate(1, runresult.getRundate());
				pstmt.setString(2, runresult.getRunstate());
			}
		});
		
		return result;
	}

	@Override
	public int update(Runresult runresult) {
		String sql = "update runresult set runstate=? where rundate=?";
		
		int result = JDBCTemplate.update(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement pstmt) throws SQLException {
				pstmt.setString(1, runresult.getRunstate());
				pstmt.setDate(2, runresult.getRundate());
			}
		});
		
		return result;
	}

	@Override
	public List<Date> queryByDatearea(Date nowdate, Date predate) {
		String sql = "select rundate from runresult where rundate>=? and rundate<=?";
		
		List<Date> dateList = JDBCTemplate.query(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement pstmt) throws SQLException {
				pstmt.setDate(1, predate);
				pstmt.setDate(2, nowdate);
			}
		}, new ResultSetCallBack<Date>() {
			@Override
			public Date processRs(ResultSet rs) throws SQLException {
				return rs.getDate(1);
			}
		});
		
		return dateList;
	}

	@Override
	public int getSuccessDate(Date nowdate, Date predate) {
		String sql = "select count(*) from runresult where rundate>=? and rundate<=?";
		
		Number num = (Number)JDBCTemplate.singleQuery(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement pstmt) throws SQLException {
				pstmt.setDate(1, predate);
				pstmt.setDate(2, nowdate);
			}
		}, new ResultSetCallBack<Number>() {
			@Override
			public Number processRs(ResultSet rs) throws SQLException {
				return rs.getInt(1);
			}
		});
		
		int result = 0;
		if(num!=null){
			result = num.intValue();
		}
		
		return result;
	}

	@Override
	public Date getMinDate() {
		String sql = "select min(rundate) from runresult";
		
		Date mindate = JDBCTemplate.singleQuery(sql, null, new ResultSetCallBack<Date>() {
			@Override
			public Date processRs(ResultSet rs) throws SQLException {
				return rs.getDate(1);
			}
		});
		
		return mindate;
	}
}
