package faceattendsystem.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import faceattendsystem.entity.Mechanism;
import faceattendsystem.service.IMechanismService;
import faceattendsystem.serviceImpl.MechanismServiceImpl;
import net.sf.json.JSONObject;

public class AddMechanismServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		IMechanismService mechanismService = new MechanismServiceImpl();
		
		String type = req.getParameter("type");
		Map<String, String> errors = new HashMap<String, String>();

		String mechid = req.getParameter("mechid");
		if(type.equals("add")){
			Mechanism mechanism = mechanismService.queryByMechid(mechid);
			if(!mechid.matches("\\d{4}")){
				errors.put("mechid", "机构号须是4位数字!");
			}else if(mechanism != null){
				errors.put("mechid", "机构号已存在!");
			}
		}
		
		String mechname = req.getParameter("mechname");
		Mechanism mechanism = mechanismService.queryByMechname(mechname);
		if (!mechname.matches("[\u4e00-\u9fa5]+")) {
			errors.put("mechname", "机构名须是常见汉字!");
		} else if (mechname.length() > 14) {
			errors.put("mechname", "机构名长度不能超过14个汉字!");
		} else if (mechanism != null) {
			if(type.equals("add")){
				errors.put("mechname", "机构名已被使用!");
			}else if(type.equals("update")){
				if(!mechanism.getMechid().equals(mechid)){
					errors.put("mechname", "机构名已被使用!");
				}
			}
		}

		String mechip = req.getParameter("mechip");
		if (!mechip.matches("\\d{1,3}.\\d{1,3}.\\*.\\*")&&!mechip.matches("\\d{1,3}.\\d{1,3}.\\*.\\d{1,3}")&&!mechip.matches("\\d{1,3}.\\d{1,3}.\\d{1,3}.\\*")) {
			errors.put("mechip", "机构IP地址须是XXX.XXX.*.*格式!");
		}

		float minsimilarity = 0;
		if(req.getParameter("minsimilarity").trim().isEmpty()){
			minsimilarity = (float) 78.0;
		}else{
			try{
				minsimilarity = Float.parseFloat(req.getParameter("minsimilarity"));
			}catch (NumberFormatException e) {
				errors.put("minsimilarity", "识别相似度须是浮点数!");
			}
			if (minsimilarity < 0 || minsimilarity > 100){
				errors.put("minsimilarity", "识别相似度须在0~100之间!");
			}
		}

		if (errors.size() != 0) {
			errors.put("flag", "1");
		} else {
			errors.put("flag", "0");
			mechanism = new Mechanism();
			mechanism.setMechid(mechid);
			mechanism.setMechname(mechname);
			mechanism.setMechip(mechip);
			mechanism.setMinsimilarity(minsimilarity);
			//Date mechdate = new Date(new java.util.Date().getTime());// 进行日期的转换
			
			if(type.equals("add")){
				mechanismService.add(mechanism);
			}else if(type.equals("update")){
				mechanismService.update(mechanism);
			}
		}
		JSONObject json = JSONObject.fromObject(errors);// 使用JSONobject将map对象转换成json对象
		PrintWriter out = resp.getWriter();
		out.print(json);
	}
}
