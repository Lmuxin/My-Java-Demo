package faceattendsystem.servlet;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import faceattendsystem.entity.Daytime;
import faceattendsystem.entity.Mechanism;
import faceattendsystem.entity.PageBean;
import faceattendsystem.service.IDaytimeService;
import faceattendsystem.service.IMechanismService;
import faceattendsystem.serviceImpl.DaytimeServiceImpl;
import faceattendsystem.serviceImpl.MechanismServiceImpl;
import faceattendsystem.util.URLUtil;



public class QueryDaytimeServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		IDaytimeService daytimeService = new DaytimeServiceImpl();
		IMechanismService mechanismService = new MechanismServiceImpl();

		String type = req.getParameter("type");
		String mechid = req.getParameter("mechid");

		if (type.equals("1")) { // 分页
			int pc = URLUtil.getPc(req);
			int ps = URLUtil.ps;
			PageBean<Daytime> pb;
			String date = req.getParameter("date");
			if (date != null) {
				Daytime daytime = new Daytime();
				Mechanism mechanism = new Mechanism();
				mechanism.setMechid(mechid);
				daytime.setMechanism(mechanism);
				
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date daybdate = null;
				try {
					daybdate = new Date(sdf.parse(date).getTime());
					daytime.setDaybdate(daybdate);
					pb = daytimeService.query(daytime, pc, ps);
				} catch (ParseException e) {
				//	System.out.println("输入日期非法!");
					pb = daytimeService.queryByMechid(mechid, pc, ps);
				}
			} else {
				pb = daytimeService.queryByMechid(mechid, pc, ps);
			}

			pb.setUrl(URLUtil.getUrl(req));
			req.setAttribute("pb", pb);
			req.setAttribute("mechid", mechid);
			req.getRequestDispatcher("jsps/daytime/list.jsp").forward(req, resp);
		} else if (type.equals("2")) {// 添加
			Mechanism mechanism = mechanismService.queryByMechid(mechid);
			req.setAttribute("mechanism", mechanism);
			req.getRequestDispatcher("jsps/daytime/add.jsp").forward(req, resp);
		}

	}
}
