package faceattendsystem.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import faceattendsystem.service.IEmployeeService;
import faceattendsystem.serviceImpl.EmployeeServiceImpl;


public class DeleteEmployeeServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		IEmployeeService employeeService = new EmployeeServiceImpl();
		String empid = req.getParameter("empid");
		int result = employeeService.delete(empid);
		String str = "{\"flag\":\""+result+"\"}";
		PrintWriter out = resp.getWriter();
		out.print(str);
		out.flush();
	}
}
