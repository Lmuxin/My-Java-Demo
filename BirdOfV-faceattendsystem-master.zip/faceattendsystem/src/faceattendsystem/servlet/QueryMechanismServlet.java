package faceattendsystem.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import faceattendsystem.entity.Mechanism;
import faceattendsystem.entity.PageBean;
import faceattendsystem.service.IMechanismService;
import faceattendsystem.serviceImpl.MechanismServiceImpl;
import faceattendsystem.util.URLUtil;



public class QueryMechanismServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		IMechanismService mechanismService = new MechanismServiceImpl();
		
		/*
		 * type 
		 * =1：查找所有机构(分页)
		 * =2：查找指定机构(修改)
		 */
		String type = req.getParameter("type");
		if(type.equals("1")){		//分页
			String mechid = req.getParameter("mechid");
			mechid = mechid==null?"":mechid;
			String mechname = req.getParameter("mechname");
			mechname = mechname==null?"":mechname;
			String mechip = req.getParameter("mechip");
			mechip = mechip==null?"":mechip;
			String minsimilarity = req.getParameter("minsimilarity");
			minsimilarity = minsimilarity==null?"0":minsimilarity;
			
			Mechanism mechanism = new Mechanism();
			mechanism.setMechid(mechid);
			mechanism.setMechname(mechname);
			mechanism.setMechip(mechip);
			mechanism.setMinsimilarity(Float.parseFloat(minsimilarity));
			
			int pc = URLUtil.getPc(req);
			int ps = URLUtil.ps;
			PageBean<Mechanism> pb = mechanismService.query(mechanism, pc, ps);
			pb.setUrl(URLUtil.getUrl(req));
			//System.out.println(pb.getUrl());
			req.setAttribute("pb", pb);
			req.getRequestDispatcher("jsps/mechanism/list.jsp").forward(req, resp);
		}else if(type.equals("2")){		//修改
			String mechid = req.getParameter("mechid");
			Mechanism mechanism = mechanismService.queryByMechid(mechid);
			req.setAttribute("mechanism", mechanism);
			req.getRequestDispatcher("jsps/mechanism/update.jsp").forward(req, resp);
		}
	}
}
