package faceattendsystem.servlet;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.python.icu.util.Calendar;

import faceattendsystem.entity.Employee;
import faceattendsystem.entity.Errorsheet;
import faceattendsystem.entity.Flowsheet;
import faceattendsystem.entity.Mechanism;
import faceattendsystem.entity.PageBean;
import faceattendsystem.service.IErrorsheetService;
import faceattendsystem.service.IFlowsheetService;
import faceattendsystem.service.ISpecdayService;
import faceattendsystem.serviceImpl.ErrorsheetServiceImpl;
import faceattendsystem.serviceImpl.FlowsheetServiceImpl;
import faceattendsystem.serviceImpl.SpecdayServiceImpl;
import faceattendsystem.util.URLUtil;



public class QueryErrorsheetServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		IErrorsheetService errorsheetService = new ErrorsheetServiceImpl();
		IFlowsheetService flowsheetService = new FlowsheetServiceImpl();
		ISpecdayService specdayService = new SpecdayServiceImpl();

		Employee employee = (Employee) req.getSession().getAttribute("employee");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String type = req.getParameter("type");
		String cxtype = req.getParameter("cxtype");
		String[] date = getDatearea(employee, req);
		if (cxtype.equals("E")) {// 异常查询
			PageBean<Errorsheet> pb = null;
			Errorsheet errorsheet = getErrorsheet(req);
			if (type.equals("1")) {// 查询
				if (date[0].compareTo(date[1]) <= 0) {// 若输入日期区间正确
					int pc = URLUtil.getPc(req);
					int ps = URLUtil.ps;
					pb = errorsheetService.query(errorsheet, date[0], date[1], pc, ps);
//					if (employee.getPower().equals("0")) {// 管理员只显示错误信息
//						pb = errorsheetService.query(errorsheet, date[0], date[1], pc, ps);
//					} else if (employee.getPower().equals("1")) {// 员工显示正常日期
//						pb = errorsheetService.queryAll(errorsheet, date[0], date[1]);
//						pb.setPc(pc);
//						pb.setPs(ps);
//						Date bdate = null, edate = null;
//						try {
//							bdate = new Date(sdf.parse(date[0]).getTime());
//						} catch (ParseException e) {
//							e.printStackTrace();
//						}
//						try {
//							edate = new Date(sdf.parse(date[1]).getTime());
//						} catch (ParseException e) {
//							e.printStackTrace();
//						}
//
//						Calendar calendar = Calendar.getInstance();
//						calendar.setTime(edate);
//						calendar.setFirstDayOfWeek(1);// 设置周日是第一天
//						List<Errorsheet> errorsheetList = pb.getBeanList();
//
//						while (bdate.compareTo(edate) < 0) {// 降序遍历
//							calendar.add(Calendar.DATE, -1);// 往前一天
//							edate = new Date((calendar.getTime()).getTime());
//							boolean flag = false;// 不存在错误记录
//							for (Errorsheet e : pb.getBeanList()) {// 遍历是否存在日期
//								if (e.getTjdate().compareTo(edate) == 0) {
//									// System.out.println(e.getTjdate()+"
//									// "+edate);
//									flag = true;
//									break;
//								}
//							}
//							if (!flag) {// 考勤状态正常
//								// 获取当前日期的类型：H、W
//								int week = calendar.get(Calendar.DAY_OF_WEEK);
//								String isWeekend = "W";
//								if (week == 1 || week == 7) { // 1:日 7:六
//									isWeekend = "H";
//								}
//								String tjtype = specdayService.queryByNowdate(edate);
//								tjtype = tjtype == null ? isWeekend : tjtype;
//
//								Errorsheet es = new Errorsheet();
//								es.setMechanism(employee.getMechanism());
//								es.setEmployee(employee);
//								es.setErrtype("00");
//								es.setTjmsg("正常正常");
//								es.setTjdate(edate);
//								es.setTjtype(tjtype);
//								errorsheetList.add(es);// 添加考勤正常记录
//							}
//						}
//
//						// 按日期大到小排序
//						Collections.sort(errorsheetList, new Comparator<Errorsheet>() {
//							@Override
//							public int compare(Errorsheet es1, Errorsheet es2) {
//								int cmp = es1.getTjdate().compareTo(es2.getTjdate());
//								//System.out.println(es1.getTjdate()+" "+es2.getTjdate()+" "+cmp);
//								return cmp<0?1:-1;
//							}
//						});
//
//						int tp = ps;
//						int tr = errorsheetList.size();
//						if (pc * ps > tr) {
//							tp = tr - (pc - 1) * ps;
//						}
//						List<Errorsheet> beanList = errorsheetList.subList((pc - 1) * ps, (pc - 1) * ps + tp);
//						pb.setTr(tr);
//						pb.setBeanList(beanList);
//					}
					pb.setUrl(URLUtil.getUrl(req));
				}
			} else if (type.equals("2")) {// 导出excel
				pb = errorsheetService.queryAll(errorsheet, date[0], date[1]);
				
			}
			req.setAttribute("pb", pb);
			req.getRequestDispatcher("jsps/attend/list.jsp").forward(req, resp);
		} else if (cxtype.equals("F")) {// 流水查询
			String empid = req.getParameter("empid");
			PageBean<Flowsheet> pb = null;
			if (type.equals("1")) {// 查询
				if (date[0].compareTo(date[1]) <= 0) {// 若输入日期区间正确
					int pc = URLUtil.getPc(req);
					int ps = URLUtil.ps;
					pb = flowsheetService.query(empid, date[0], date[1], pc, ps);
					pb.setUrl(URLUtil.getUrl(req));
				}
			} else if (type.equals("2")) {// 导出excel
				pb = flowsheetService.queryAll(empid, date[0], date[1]);
			}
			req.setAttribute("pb", pb);
			req.getRequestDispatcher("jsps/attend/flowlist.jsp").forward(req, resp);
		}
	}

	private String[] getDatearea(Employee employee, HttpServletRequest req) {
		IFlowsheetService flowsheetService = new FlowsheetServiceImpl();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String bdate = req.getParameter("bdate");
		if (bdate == "") {
			bdate = flowsheetService.getMindate(employee).toString();
		}
		String edate = req.getParameter("edate");
		if (edate == "") {
			edate = sdf.format(new java.util.Date());
		}
		String[] date = new String[2];
		date[0] = bdate;
		date[1] = edate;
		return date;
	}

	private Errorsheet getErrorsheet(HttpServletRequest req) {
		String mechid = req.getParameter("mechid");
		Employee e = (Employee) req.getSession().getAttribute("employee");
		if (mechid == null) {
			mechid = e.getMechanism().getMechid();
		}

		String empid = req.getParameter("empid");
		if (empid == null) {
			empid = e.getEmpid();
		}
		String tjtype = req.getParameter("tjtype");
		tjtype = tjtype == null ? "" : tjtype;

		Errorsheet errorsheet = new Errorsheet();
		Mechanism mechanism = new Mechanism();
		mechanism.setMechid(mechid);
		errorsheet.setMechanism(mechanism);
		Employee employee = new Employee();
		employee.setEmpid(empid);
		errorsheet.setEmployee(employee);
		errorsheet.setTjtype(tjtype);

		return errorsheet;
	}
}
