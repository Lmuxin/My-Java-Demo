package faceattendsystem.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import faceattendsystem.entity.Employee;
import faceattendsystem.entity.Mechanism;
import faceattendsystem.entity.PageBean;
import faceattendsystem.service.IEmployeeService;
import faceattendsystem.service.IMechanismService;
import faceattendsystem.serviceImpl.EmployeeServiceImpl;
import faceattendsystem.serviceImpl.MechanismServiceImpl;
import faceattendsystem.util.URLUtil;



public class QueryEmployeeServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		IEmployeeService employeeService = new EmployeeServiceImpl();
		IMechanismService mechanismService = new MechanismServiceImpl();
		/*
		 * type 
		 * =1：查找所有员工(分页)
		 * =2：查找指定员工(修改、添加、查询、选择机构)
		 */
		
		String type = req.getParameter("type");
		if(type.equals("1")){
			String mechid = req.getParameter("mechid");
			mechid = mechid==null?"":mechid;
			String empid = req.getParameter("empid");
			empid = empid==null?"":empid;
			String name = req.getParameter("name");
			name = name==null?"":name;
			String idnumber = req.getParameter("idnumber");
			idnumber = idnumber==null?"":idnumber;
			
			Employee employee = new Employee();
			Mechanism mechanism = new Mechanism();
			mechanism.setMechid(mechid);
			employee.setMechanism(mechanism);
			employee.setEmpid(empid);
			employee.setName(name);
			employee.setIdnumber(idnumber);
			int pc = URLUtil.getPc(req);
			int ps = URLUtil.ps;
			PageBean<Employee> pb = employeeService.query(employee, pc, ps);
			pb.setUrl(URLUtil.getUrl(req));
			req.setAttribute("pb", pb);
			req.getRequestDispatcher("jsps/employee/list.jsp").forward(req, resp);
		}else if(type.equals("2")){
			List<Mechanism> mechanismList = mechanismService.queryAll();
			req.setAttribute("mechanismList", mechanismList);
			String path = "",way=req.getParameter("way");
			if(way.equals("1")){
				path = "jsps/employee/query.jsp";
			}else if(way.equals("2")){
				path = "jsps/employee/add.jsp";
			}else if(way.equals("3")){
				String empid = req.getParameter("empid");
				Employee employee = employeeService.queryByEmpid(empid);
				employee.setPicmd5(getPic(employee));
				req.setAttribute("employee", employee);
				path = "jsps/employee/update.jsp";
			}
			req.getRequestDispatcher(path).forward(req, resp);
		}else if(type.equals("3")){
			String empid = req.getParameter("empid");
			Employee employee = employeeService.queryByEmpid(empid);
			String power = employee.getPower();
			if(power.equals("1")){
				power = "普通权限";
			}else if(power.equals("0")){
				power = "管理员权限";
			}
			String state = employee.getState();
			if(state.equals("0")){
				state = "任职状态";
			}else if(state.equals("1")){
				state = "离职状态";
			}
			employee.setPower(power);
			employee.setState(state);
			
			employee.setPicmd5(getPic(employee));
			
			req.setAttribute("employee", employee);
			req.getRequestDispatcher("jsps/employee/desc.jsp").forward(req, resp);
		}
	}

	private String getPic(Employee employee) {
		String empid = employee.getEmpid();
		String realPath = empid+".bmp";
		return realPath;
	}
}
