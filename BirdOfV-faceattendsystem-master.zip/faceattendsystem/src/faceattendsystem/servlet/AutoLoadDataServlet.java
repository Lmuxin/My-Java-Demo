//package FaceAttendSystem.Servlet;
//
//import java.sql.Date;
//import java.util.Calendar;
//import java.util.List;
//import java.util.Timer;
//import java.util.TimerTask;
//
//import javax.servlet.ServletConfig;
//import javax.servlet.ServletException;
//import javax.servlet.http.HttpServlet;
//
//import FaceAttendSystem.Entity.Daytime;
//import FaceAttendSystem.Entity.Employee;
//import FaceAttendSystem.Entity.Errorsheet;
//import FaceAttendSystem.Entity.Flowsheet;
//import FaceAttendSystem.Entity.Mechanism;
//import FaceAttendSystem.Entity.Runresult;
//import FaceAttendSystem.Service.IDaytimeService;
//import FaceAttendSystem.Service.IEmployeeService;
//import FaceAttendSystem.Service.IErrorsheetService;
//import FaceAttendSystem.Service.IFlowsheetService;
//import FaceAttendSystem.Service.IMechanismService;
//import FaceAttendSystem.Service.IRunresultService;
//import FaceAttendSystem.Service.ISpecdayService;
//import FaceAttendSystem.ServiceImpl.DaytimeServiceImpl;
//import FaceAttendSystem.ServiceImpl.EmployeeServiceImpl;
//import FaceAttendSystem.ServiceImpl.ErrorsheetServiceImpl;
//import FaceAttendSystem.ServiceImpl.FlowsheetServiceImpl;
//import FaceAttendSystem.ServiceImpl.MechanismServiceImpl;
//import FaceAttendSystem.ServiceImpl.RunresultServiceImpl;
//import FaceAttendSystem.ServiceImpl.SpecdayServiceImpl;
//
//public class AutoLoadDataServlet extends HttpServlet {
//
//	@Override
//	public void init(ServletConfig config) throws ServletException {
//		super.init(config);
//
//		IMechanismService mechanismService = new MechanismServiceImpl();
//		IEmployeeService employeeService = new EmployeeServiceImpl();
//		IDaytimeService daytimeService = new DaytimeServiceImpl();
//		ISpecdayService specdayService = new SpecdayServiceImpl();
//		IFlowsheetService flowsheetService = new FlowsheetServiceImpl();
//		IErrorsheetService errorsheetService = new ErrorsheetServiceImpl();
//		IRunresultService runresultService = new RunresultServiceImpl();
//
//		TimerTask task = new TimerTask() {
//			@Override
//			public void run() {
//				// 当前日期
//				Date nowdate = new Date(new java.util.Date().getTime());
//				Calendar calendar = Calendar.getInstance();
//				// 或者用 Date 来初始化 Calendar 对象
//				calendar.setTime(nowdate);
//
//				// 获取当前日期的类型：H、W
//				calendar.setFirstDayOfWeek(1);//设置周日是第一天
//				int week = calendar.get(Calendar.DAY_OF_WEEK);
//				String isWeekend = "W";
//				if (week == 1 || week == 7) { // 1:日 7:六
//					isWeekend = "H";
//					//System.out.println(nowdate + "是周末");
//				}
//				String tjtype = specdayService.queryByNowdate(nowdate);
//				tjtype = tjtype == null ? isWeekend : tjtype;
//
//				Runresult runresult = new Runresult();
//				runresult.setRundate(nowdate);
//				
//				// 获取当前时间的运行状态
//				String runstate = runresultService.queryByNowdate(nowdate);
//				if (runstate == null || runstate.equals("1")) {
//					System.out.println("进行更新");
//
//					// 获取所有机构
//					List<Mechanism> mechanismList = mechanismService.queryAll();
//					for (Mechanism mechanism : mechanismList) {
//						// 比较机构考勤数据更新日期，生成新的errorsheet记录
//						String mechip = mechanism.getMechip();
//						String[] mechipArr = mechip.split("\\.");// 196.12.*.*拆分
//						String mechid = mechanism.getMechid();
//
//						// 获取机构工作时间
//						Daytime daytime = daytimeService.queryByMechid(mechid, nowdate);
//						int begintime = Integer.parseInt(daytime.getBegintime());
//						int endtime = Integer.parseInt(daytime.getEndtime());
//						//System.out.println(nowdate + "工作时间: " + begintime + "~" + endtime);
//
//						// 获取机构所有员工
//						List<Employee> employeeList = employeeService.queryByMechid(mechid);
//						for (Employee employee : employeeList) {
//							List<Flowsheet> flowsheetList = flowsheetService.query(nowdate, employee.getEmpid());
//							//System.out.println(flowsheetList);
//							String errtype, tjmsg;
//							if (flowsheetList != null) {
//								String data = getErrTypeMsg(flowsheetList, mechipArr, begintime, endtime);
//								String[] dataArr = data.split(" ");
//								errtype = dataArr[0];
//								tjmsg = dataArr[1];
//							} else {
//								errtype = "11";
//								tjmsg = "未签到未签退";
//							}
//
//							// 添加错误记录
//							if (!errtype.equals("00")) {
//								Errorsheet errorsheet = new Errorsheet();
//								errorsheet.setMechanism(mechanism);
//								errorsheet.setEmployee(employee);
//								errorsheet.setTjdate(nowdate);
//								errorsheet.setErrtype(errtype);
//								errorsheet.setTjtype(tjtype);
//								errorsheet.setTjmsg(tjmsg);
//								int result = errorsheetService.add(errorsheet);
//							//	System.out.println("插入数据结果:" + result);
//							}
//						}
//					}
//					runresult.setRunstate("0");
//					int result = runresultService.add(runresult);
//					//System.out.println("添加结果：1成功0失败"+result);
//				} else {
//					System.out.println("已更新");
//				}
//			}
//		};
//
//		// 设置执行时间
//		Calendar calendar = Calendar.getInstance();
//		int year = calendar.get(Calendar.YEAR);
//		int month = calendar.get(Calendar.MONTH);
//		int day = calendar.get(Calendar.DAY_OF_MONTH);// 每天
//		// 定制每天的21:00:00执行
//		calendar.set(year, month, day, 14, 8, 00);
//		Timer timer = new Timer();
//		int period = 24 * 60 * 60 * 1000;
//		// 每天的date时刻执行task，每隔一天重复执行
//		timer.schedule(task, calendar.getTime(), period);
//	}
//
//	// 获取错误类型和异常描述
//	private String getErrTypeMsg(List<Flowsheet> flowsheetList, String[] mechipArr, int begintime, int endtime) {
//		int logNum = flowsheetList.size();
//		boolean[] flagArr = new boolean[logNum];
//		for (int i = 0; i < flowsheetList.size(); i++) {
//			// 比较ip地址是否有效
//			String logip = flowsheetList.get(i).getLogip();
//			String[] logipArr = logip.split("\\.");
//			flagArr[i] = true;
//			for (int j = 0; j < mechipArr.length; j++) {
//				System.out.println(mechipArr[j] + " " + logipArr[j]);
//				if (!mechipArr[j].equals("*")) {// 若不是*,则比较ip
//					if (!logipArr[j].equals(mechipArr[j])) {
//						flagArr[i] = false;
//						logNum--;
//						break;
//					}
//				}
//			}
//			System.out.println(flagArr[i]);
//		}
//
//		/*
//		 * 筛选至此，判断记录数 若>1,则取最早和最晚; 若==1,则判断时间所在范围; 若==0,则未签到未签退
//		 */
//		String errtype = null, tjmsg = null;
//		int logtime1 = 0, logtime2 = 0;
//		System.out.println("有效记录数=" + logNum);
//		if (logNum > 1) {
//			for (int i = 0; i < flowsheetList.size(); i++) {
//				if (flagArr[i]) {// 最早有效记录
//					logtime1 = flowsheetList.get(i).getLogtime();
//					break;
//				}
//			}
//			for (int i = flowsheetList.size() - 1; i >= 0; i--) {
//				if (flagArr[i]) {// 最晚有效记录
//					logtime2 = flowsheetList.get(i).getLogtime();
//					break;
//				}
//			}
//			// 若第一次签到时间比下班时间晚，则是未签到正常
//			if (logtime1 <= begintime) {
//				errtype = "0";
//				tjmsg = "正常";
//			} else if (logtime1 > endtime) {
//				errtype = "1";
//				tjmsg = "未签到";
//			} else {
//				errtype = "2";
//				tjmsg = "迟到";
//			}
//			if (logtime2 >= endtime) {
//				errtype += "0";
//				tjmsg += "正常";
//			} else {
//				errtype += "2";
//				tjmsg += "早退";
//			}
//		} else if (logNum == 1) {
//			for (int i = 0; i < flowsheetList.size(); i++) {
//				if (flagArr[i]) {// 唯一有效记录
//					logtime1 = flowsheetList.get(i).getLogtime();
//					break;
//				}
//			}
//			if (logtime1 <= begintime) {
//				errtype = "01";
//				tjmsg = "正常未签退";
//			} else if (logtime1 > begintime & logtime1 < endtime) {
//				if (logtime1 - begintime > endtime - logtime1) {// 距离下班时间近，则未签到早退
//					errtype = "12";
//					tjmsg = "未签到早退";
//				} else {
//					errtype = "21";
//					tjmsg = "迟到未签退";
//				}
//			} else {
//				errtype = "10";
//				tjmsg = "未签到正常";
//			}
//		} else {
//			errtype = "11";
//			tjmsg = "未签到未签退";
//		}
//
//		return errtype + " " + tjmsg;
//	}
//}
