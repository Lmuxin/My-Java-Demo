package faceattendsystem.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import faceattendsystem.entity.PageBean;
import faceattendsystem.entity.Specday;
import faceattendsystem.service.ISpecdayService;
import faceattendsystem.serviceImpl.SpecdayServiceImpl;
import faceattendsystem.util.URLUtil;
import net.sf.json.JSONObject;

public class QuerySpecdayServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ISpecdayService specdayService = new SpecdayServiceImpl();
		
		String type = req.getParameter("type");
		if(type.equals("1")){
			int pc = URLUtil.getPc(req);
			int ps = URLUtil.ps;
			
			PageBean<Specday> pb;
			String date = req.getParameter("date");
			if(date!=null){
				Specday specday = new Specday();
				
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date specbdate = null;
				try {
					specbdate = new Date(sdf.parse(date).getTime());
					specday.setSpecbdate(specbdate);
					pb = specdayService.query(specday, pc, ps);
				} catch (ParseException e) {
					//System.out.println("输入日期非法!");
					pb = specdayService.queryAll(pc, ps);
				}
			}else{
				pb = specdayService.queryAll(pc, ps);
			}
			
			pb.setUrl(URLUtil.getUrl(req));
			req.setAttribute("pb", pb);
			req.getRequestDispatcher("jsps/specday/list.jsp").forward(req, resp);
		}else if(type.equals("2")){
			String specname = req.getParameter("specname");
			specname = specname==null?"":specname;
			String spectype = req.getParameter("spectype");
			spectype = spectype==null?"":spectype;
			String specbdate = req.getParameter("specbdate");
			String specedate = req.getParameter("specedate");
			Map<String,String> errors = new HashMap<String,String>();
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date bdate=null;
			try {
				bdate = new Date(sdf.parse(specbdate).getTime());
			} catch (ParseException e) {
				errors.put("specbdate", "开始日期错误!");
			}
			
			Date edate=null;
			try {
				edate = new Date(sdf.parse(specedate).getTime());
			} catch (ParseException e) {
				errors.put("specedate", "结束日期错误!");
			}
			
			if(errors.size()!=0){
				JSONObject json = JSONObject.fromObject(errors);
				PrintWriter writer = resp.getWriter();
				writer.print(json);
			}else{
				Specday specday = new Specday();
				specday.setSpecbdate(bdate);
				specday.setSpecedate(edate);
				specday.setSpecname(specname);
				specday.setDaytype(spectype);
				int pc = URLUtil.getPc(req);
				int ps = URLUtil.ps;
				PageBean<Specday> pb = specdayService.query(specday,pc, ps);
				pb.setUrl(URLUtil.getUrl(req));
				req.setAttribute("pb", pb);
				req.getRequestDispatcher("jsps/specday/list.jsp").forward(req, resp);
			}
		}
	}
}
