package faceattendsystem.servlet;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import faceattendsystem.entity.Employee;
import faceattendsystem.entity.Mechanism;
import faceattendsystem.entity.PageBean;
import faceattendsystem.service.IFlowsheetService;
import faceattendsystem.service.IMechanismService;
import faceattendsystem.service.IRunresultService;
import faceattendsystem.serviceImpl.FlowsheetServiceImpl;
import faceattendsystem.serviceImpl.MechanismServiceImpl;
import faceattendsystem.serviceImpl.RunresultServiceImpl;
import faceattendsystem.util.DateAreaUtil;
import faceattendsystem.util.URLUtil;



public class QueryRunresultServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		IRunresultService runresultService = new RunresultServiceImpl();
		IMechanismService mechanismService = new MechanismServiceImpl();
		IFlowsheetService flowsheetService = new FlowsheetServiceImpl();
		
		//获取最小的日期
		Employee employee = (Employee) req.getSession().getAttribute("employee");
		Date mindate = flowsheetService.getMindate(employee);
		
		String type = req.getParameter("type");
		if(type.equals("1")){
			int errorNum = 0;
			if(mindate!=null){
				//获取实际有效天数
				int daynum = DateAreaUtil.getDatedata(mindate,DateAreaUtil.daynum);
				Date nowdate = new Date(new java.util.Date().getTime());
				Calendar calendar = Calendar.getInstance();
				calendar.add(Calendar.DATE,-daynum);
				Date predate = new Date(calendar.getTime().getTime());
				errorNum = daynum-runresultService.getSuccessDate(nowdate, predate);
			}
			
			req.setAttribute("errorNum", errorNum);
			//System.out.println("errorNum="+errorNum);
			
			List<Mechanism> mechanismList = mechanismService.queryAll();
			req.setAttribute("mechanismList", mechanismList);
			req.getRequestDispatcher("jsps/attend/query.jsp").forward(req, resp);
		}else if(type.equals("2")){
			int daynum = DateAreaUtil.getDatedata(mindate,DateAreaUtil.daynum);
			Date nowdate = new Date(new java.util.Date().getTime());
			Calendar calendar = Calendar.getInstance();
			calendar.add(Calendar.DATE,-daynum);
			Date predate = new Date(calendar.getTime().getTime());
			
			//获取时间段内的成功的日期集合，之后遍历100天，获取需要重新跑的。
			List<Date> errorDateList = new ArrayList<Date>();
			Date date = null;
			List<Date> dateList = runresultService.queryByDatearea(nowdate, predate);
			
			if(dateList.size()!=daynum){
				for(int i=0;i<daynum;i++){//遍历所有日期
					date = new Date(calendar.getTime().getTime());
					boolean flag = false;
					for(Date d:dateList){
						if(d.toString().equals(date.toString())){	//若相等
							flag = true;
						}
					}
					if(!flag){//若不存在
						errorDateList.add(date);
					}
					calendar.add(Calendar.DATE, 1);
				}
			}
			
			
			int pc = URLUtil.getPc(req);
			int ps = URLUtil.ps;
			int tr = errorDateList.size();
			//System.out.println(tr);
			int tp=ps;
			if(pc*ps>tr){
				tp = tr-(pc-1)*ps;
			}
			dateList = errorDateList.subList((pc-1)*ps, (pc-1)*ps+tp);
			
			PageBean<Date> pb = new PageBean<Date>();
			pb.setBeanList(dateList);
			pb.setPc(pc);
			pb.setPs(ps);
			pb.setTr(tr);
			pb.setUrl(URLUtil.getUrl(req));
			req.setAttribute("pb", pb);
			req.getRequestDispatcher("jsps/attend/errorlist.jsp").forward(req, resp);
		}
	}
}
