开发环境：windows+eclipse+mysql+tomcat9+jdk1.8

配置sql：复制faceattendsystem\WebContent\sql\faceattendsystem.sql存到本地mysql,
        配置的mysql数据库在faceattendsystem\src\faceattendsystem\util\jdbcinfo.properties

测试数据：管理员的登录账号是admin,初始密码是111111；员工的登录账号是工号，初始密码是111111