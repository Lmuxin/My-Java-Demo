function postAdminLogin(id, pw) {
	$.ajax({
		type : "POST",
		url : "adminLogin",
		data : "id=" + id + "&&pw=" + pw,
		success : function(msg) {
			alert(msg);
			// window.location.href = "";
		},
		error : function(msg) {
			alert("Connection error");
		}
	});
}