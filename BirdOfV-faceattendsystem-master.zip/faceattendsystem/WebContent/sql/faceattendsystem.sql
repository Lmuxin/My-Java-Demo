/*
Navicat MySQL Data Transfer

Source Server         : mydb
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : faceattendsystem

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2018-05-07 14:27:29
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for daytime
-- ----------------------------
DROP TABLE IF EXISTS `daytime`;
CREATE TABLE `daytime` (
  `daybdate` date NOT NULL COMMENT '时间号',
  `dayedate` date NOT NULL,
  `daytype` varchar(1) NOT NULL COMMENT '作息类型',
  `mechid` varchar(4) NOT NULL COMMENT '机构号',
  `begintime` int(6) NOT NULL COMMENT '具体日期',
  `endtime` int(6) NOT NULL COMMENT '开始时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of daytime
-- ----------------------------
INSERT INTO `daytime` VALUES ('2017-10-01', '2018-04-30', 'W', '0001', '80000', '163000');
INSERT INTO `daytime` VALUES ('2017-10-01', '2018-04-30', 'W', '0002', '80000', '170000');
INSERT INTO `daytime` VALUES ('2018-11-28', '2019-11-28', 'W', '0001', '0', '103652');

-- ----------------------------
-- Table structure for employee
-- ----------------------------
DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee` (
  `mechid` varchar(4) DEFAULT NULL COMMENT '机构号',
  `empid` varchar(8) NOT NULL DEFAULT '' COMMENT '员工号',
  `password` varchar(32) DEFAULT NULL COMMENT '密码',
  `name` varchar(20) DEFAULT NULL COMMENT '员工姓名',
  `idnumber` char(18) DEFAULT NULL COMMENT '身份证号',
  `power` varchar(1) DEFAULT NULL,
  `picmd5` varchar(32) DEFAULT NULL COMMENT '员工图片',
  `state` char(2) DEFAULT NULL COMMENT '员工状态',
  PRIMARY KEY (`empid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of employee
-- ----------------------------
INSERT INTO `employee` VALUES ('0001', '1003', '96e79218965eb72c92a549dd5a330112', '小立', '330511197010114410', '1', 'f79ddc9561779d7d6e1ac2b45fc2a13f', '0');
INSERT INTO `employee` VALUES ('0001', '1026', '96e79218965eb72c92a549dd5a330112', '小颖', '330126197601203121', '1', 'd81df99210a76764b942c72c3a7f5c1a', '0');
INSERT INTO `employee` VALUES ('0001', '1170', '96e79218965eb72c92a549dd5a330112', '小江', '330501197802215812', '1', '698a39ace3aaaec2726dae996bc6fb06', '0');
INSERT INTO `employee` VALUES ('0001', '1236', '96e79218965eb72c92a549dd5a330112', '小瑾', '330511197110031260', '1', '6808a1b456ca98815fc43ebc11934995', '0');
INSERT INTO `employee` VALUES ('0002', '1302', '96e79218965eb72c92a549dd5a330112', '小侠', '342130196402070066', '1', '7ad054219fdc61db330b152a6edd05ff', '0');
INSERT INTO `employee` VALUES ('0002', '1306', '96e79218965eb72c92a549dd5a330112', '小荣', '330511196702126811', '1', '3c1e4bcc7fe3d54c736d9f9d5c4afab9', '0');
INSERT INTO `employee` VALUES ('0002', '1307', '96e79218965eb72c92a549dd5a330112', '小洵', '330511197010242817', '1', '0360dda41f3eb6232a73580a6e31a78d', '0');
INSERT INTO `employee` VALUES (null, 'admin', '96e79218965eb72c92a549dd5a330112', 'admin', null, '0', null, '0');

-- ----------------------------
-- Table structure for errorsheet
-- ----------------------------
DROP TABLE IF EXISTS `errorsheet`;
CREATE TABLE `errorsheet` (
  `tjdate` date NOT NULL COMMENT '记录日期',
  `mechid` char(4) NOT NULL COMMENT '机构号',
  `empid` varchar(8) NOT NULL COMMENT '工号',
  `errtype` varchar(3) NOT NULL COMMENT '记录状态',
  `tjtype` varchar(2) NOT NULL COMMENT '记录类型',
  `tjmsg` varchar(200) NOT NULL COMMENT '异常描述'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of errorsheet
-- ----------------------------
INSERT INTO `errorsheet` VALUES ('2017-11-14', '0001', '1003', '22', 'W', '迟到且早退');
INSERT INTO `errorsheet` VALUES ('2017-11-14', '0001', '1026', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-14', '0001', '1170', '21', 'W', '迟到且未签退');
INSERT INTO `errorsheet` VALUES ('2017-11-14', '0001', '1236', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-14', '0002', '1302', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-14', '0002', '1306', '21', 'W', '迟到且未签退');
INSERT INTO `errorsheet` VALUES ('2017-11-14', '0002', '1307', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-15', '0001', '1003', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-15', '0001', '1026', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-15', '0001', '1170', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-15', '0001', '1236', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-15', '0002', '1302', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-15', '0002', '1306', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-15', '0002', '1307', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-16', '0001', '1003', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-16', '0001', '1026', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-16', '0001', '1170', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-16', '0001', '1236', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-16', '0002', '1302', '21', 'W', '迟到且未签退');
INSERT INTO `errorsheet` VALUES ('2017-11-16', '0002', '1306', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-16', '0002', '1307', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-17', '0001', '1003', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-17', '0001', '1026', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-17', '0001', '1170', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-17', '0001', '1236', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-17', '0002', '1302', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-17', '0002', '1306', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-17', '0002', '1307', '22', 'W', '迟到且早退');
INSERT INTO `errorsheet` VALUES ('2017-11-20', '0001', '1003', '10', 'W', '未签到');
INSERT INTO `errorsheet` VALUES ('2017-11-20', '0001', '1026', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-20', '0001', '1170', '10', 'W', '未签到');
INSERT INTO `errorsheet` VALUES ('2017-11-20', '0001', '1236', '10', 'W', '未签到');
INSERT INTO `errorsheet` VALUES ('2017-11-20', '0002', '1302', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-20', '0002', '1306', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-20', '0002', '1307', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-21', '0001', '1026', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-21', '0001', '1170', '01', 'W', '未签退');
INSERT INTO `errorsheet` VALUES ('2017-11-21', '0001', '1236', '20', 'W', '迟到');
INSERT INTO `errorsheet` VALUES ('2017-11-21', '0002', '1302', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-21', '0002', '1306', '11', 'W', '无考勤记录');
INSERT INTO `errorsheet` VALUES ('2017-11-21', '0002', '1307', '11', 'W', '无考勤记录');

-- ----------------------------
-- Table structure for flowsheet
-- ----------------------------
DROP TABLE IF EXISTS `flowsheet`;
CREATE TABLE `flowsheet` (
  `logdate` date DEFAULT NULL,
  `logtime` int(6) DEFAULT NULL,
  `empid` varchar(8) DEFAULT NULL,
  `clientdatetime` varchar(15) DEFAULT NULL,
  `logip` varchar(16) DEFAULT NULL,
  `rtn` int(6) DEFAULT NULL,
  `message` varchar(60) DEFAULT NULL,
  `similarity` float(10,5) DEFAULT NULL,
  `requestid` varchar(32) DEFAULT NULL,
  `result` varchar(2) DEFAULT NULL,
  `picmd5` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of flowsheet
-- ----------------------------
INSERT INTO `flowsheet` VALUES ('2017-11-14', '143835', '1003', '20171114143921', '179.78.1.141', '0', 'OK', '83.23319', 'AAAAAOyLTVzyXQUAjwcAAAAAAADqAQAA', '1', '8e92f9797a91c54e71e9ee7f4a57ba41');
INSERT INTO `flowsheet` VALUES ('2017-11-14', '143903', '1003', '20171114143948', '179.78.1.141', '0', 'OK', '83.08920', 'AAAAANly9V3yXQUAjgcAAAAAAADrAQAA', '1', '0a39fc23da6b5dce94d3677fd06f4d42');
INSERT INTO `flowsheet` VALUES ('2017-11-14', '144204', '1170', '20171114144249', '179.78.1.141', '0', 'OK', '82.31472', 'AAAAAAmhuGjyXQUAlgcAAAAAAADtAQAA', '1', '6017173a3498ca94c9a1db3f7edd17b2');
INSERT INTO `flowsheet` VALUES ('2017-11-14', '163549', '1306', '20171114163543', '179.77.1.1', '0', 'OK', '83.26752', 'AAAAABLg0fzzXQUAlQcAAAAAAAAQAgAA', '1', '0fc7a5a7dc1e817356ea5b10430c4e67');
INSERT INTO `flowsheet` VALUES ('2017-11-16', '85505', '1302', '20171116085501', '179.77.1.5', '0', 'OK', '66.04532', 'AAAAAAFNwcgVXgUAlQcAAAAAAABXAgAA', '0', null);
INSERT INTO `flowsheet` VALUES ('2017-11-16', '85602', '1302', '20171116085558', '179.77.1.5', '0', 'OK', '65.94838', 'AAAAAE1/JcwVXgUAkQcAAAAAAABYAgAA', '0', null);
INSERT INTO `flowsheet` VALUES ('2017-11-16', '85641', '1302', '20171116085636', '179.77.1.5', '0', 'OK', '75.78927', 'AAAAAN58cs4VXgUAkAcAAAAAAABZAgAA', '0', null);
INSERT INTO `flowsheet` VALUES ('2017-11-16', '85712', '1302', '20171116085708', '179.77.1.5', '0', 'OK', '75.50926', 'AAAAACcfUdAVXgUAkwcAAAAAAABaAgAA', '0', null);
INSERT INTO `flowsheet` VALUES ('2017-11-16', '85801', '1302', '20171116085759', '179.77.1.5', '0', 'OK', '71.50957', 'AAAAAF8yQNMVXgUAkAcAAAAAAABbAgAA', '0', null);
INSERT INTO `flowsheet` VALUES ('2017-11-16', '85833', '1302', '20171116085828', '179.77.1.5', '0', 'OK', '78.73828', 'AAAAAGxxHtUVXgUAkgcAAAAAAABcAgAA', '1', '1dbe7bea0b3bc6bcd072f8bba5f6f595');
INSERT INTO `flowsheet` VALUES ('2017-11-17', '162309', '1307', '20171117162306', '179.77.1.6', '0', 'OK', '83.09656', 'AAAAAFGy8igwXgUAjwcAAAAAAAC3AgAA', '1', 'b539486e6177ab9e2035a7a02708d822');
INSERT INTO `flowsheet` VALUES ('2017-11-17', '162358', '1307', '20171117162355', '179.77.1.6', '0', 'OK', '83.16530', 'AAAAAMYy3yswXgUAlAcAAAAAAAC4AgAA', '1', 'b3c2f6d97eaac924477ca4e33d10ab2c');
INSERT INTO `flowsheet` VALUES ('2017-11-20', '172349', '1003', '20171120172348', '179.78.1.141', '0', 'OK', '81.83457', 'AAAAANFyWVttXgUAkQcAAAAAAADfAgAA', '1', '5dc64bb887a1a844f0965243386e376c');
INSERT INTO `flowsheet` VALUES ('2017-11-20', '175424', '1236', '20171120175421', '179.78.1.115', '0', 'OK', '83.07101', 'AAAAAH2XvshtXgUAjgcAAAAAAADiAgAA', '1', '150997c8fcec903a4d53718b1c0431c3');
INSERT INTO `flowsheet` VALUES ('2017-11-20', '192108', '1170', '20171120192107', '179.78.1.31', '0', 'OK', '83.02804', 'AAAAAC3F5v5uXgUAkwcAAAAAAADnAgAA', '1', '86ad3ac9dd737fb6bfa116d0d74f8f37');
INSERT INTO `flowsheet` VALUES ('2017-11-21', '74944', '1170', '20171121074944', '179.78.1.31', '0', 'OK', '83.01634', 'AAAAALfrG3R5XgUAjQcAAAAAAAD2AgAA', '1', '463c9f71c33ef54aa092aa1d07b3d29b');
INSERT INTO `flowsheet` VALUES ('2017-11-21', '75202', '1003', '20171121075201', '179.78.1.141', '0', 'OK', '83.18559', 'AAAAAOypUHx5XgUAkwcAAAAAAAD4AgAA', '1', 'd527e66fb5237140551c3cd2a8fff6c5');
INSERT INTO `flowsheet` VALUES ('2017-11-21', '80312', '1236', '20171121080309', '179.78.1.115', '0', 'OK', '83.17444', 'AAAAACpiQ6R5XgUAlAcAAAAAAAD/AgAA', '1', '39981cc6628dd74e15f4577789148878');
INSERT INTO `flowsheet` VALUES ('2017-11-21', '181607', '1236', '20171121181603', '179.78.1.115', '0', 'OK', '83.00818', 'AAAAAPzyLDSCXgUAmQcAAAAAAAAQAwAA', '1', '88e664d0b6ff493417d7ae0bff2c52aa');
INSERT INTO `flowsheet` VALUES ('2017-11-21', '203405', '1003', '20171121203404', '179.78.1.141', '0', 'OK', '83.08389', 'AAAAACBhliGEXgUAjQcAAAAAAAAWAwAA', '1', '42ea6789bbbde2ce463464d8dacc1e72');
INSERT INTO `flowsheet` VALUES ('2017-11-22', '75637', '1170', '20171122075636', '179.78.1.31', '0', 'OK', '83.16398', 'AAAAALNoiKqNXgUAmwcAAAAAAAAoAwAA', '1', 'bd5769ecc39521e90039abdfb4a06c6f');
INSERT INTO `flowsheet` VALUES ('2017-11-22', '75855', '1236', '20171122075852', '179.78.1.115', '0', 'OK', '83.22365', 'AAAAABXbxbKNXgUAkgcAAAAAAAAqAwAA', '1', '7aa5cbe02d224dc356704f7960279134');
INSERT INTO `flowsheet` VALUES ('2017-11-22', '91226', '1003', '20171122091226', '179.78.1.141', '0', 'OK', '83.13016', 'AAAAANkwsLmOXgUAlwcAAAAAAAAtAwAA', '1', '261c08424117c5db376d3a397e274e07');
INSERT INTO `flowsheet` VALUES ('2017-11-22', '184633', '1236', '20171122184630', '179.78.1.115', '0', 'OK', '83.10318', 'AAAAAEQ+376WXgUAkgcAAAAAAABAAwAA', '1', '5c539b9c445176166da1ef52a968ac38');
INSERT INTO `flowsheet` VALUES ('2017-11-22', '194950', '1170', '20171122194949', '179.78.1.31', '0', 'OK', '83.02829', 'AAAAAHJVKaGXXgUAmAcAAAAAAABCAwAA', '1', '0ae1c3b4aeda91e8eb51387175b3f4b9');
INSERT INTO `flowsheet` VALUES ('2017-11-22', '200700', '1003', '20171122200659', '179.78.1.141', '0', 'OK', '83.20272', 'AAAAAHWNjd6XXgUAmQcAAAAAAABDAwAA', '1', '70622d3ca81b575c1eb28d346840c137');
INSERT INTO `flowsheet` VALUES ('2017-11-23', '75516', '1170', '20171123075516', '179.78.1.31', '0', 'OK', '83.15742', 'AAAAAE4+gsOhXgUAjwcAAAAAAABVAwAA', '1', '83bbccaf6a0b7283e4ff30669045cefa');
INSERT INTO `flowsheet` VALUES ('2017-11-23', '75822', '1003', '20171123075821', '179.78.1.141', '0', 'OK', '83.14435', 'AAAAAGLzlc6hXgUAjgcAAAAAAABXAwAA', '1', 'b47cc1b94452515997f37e26d401a110');
INSERT INTO `flowsheet` VALUES ('2017-11-23', '80048', '1236', '20171123080044', '179.78.1.115', '0', 'OK', '83.19396', 'AAAAAFUbRNehXgUAlgcAAAAAAABYAwAA', '1', 'df06343437315afb4f6d18ec6bee17d2');
INSERT INTO `flowsheet` VALUES ('2017-11-23', '171235', '1170', '20171123171234', '179.78.1.31', '0', 'OK', '83.04354', 'AAAAAE1bl4ypXgUAmwcAAAAAAABuAwAA', '1', '6843a7d387b53b6401780f5634dbf8f6');
INSERT INTO `flowsheet` VALUES ('2017-11-23', '203902', '1003', '20171123203902', '179.78.1.141', '0', 'OK', '82.45652', 'AAAAAKL17W6sXgUAmQcAAAAAAAB7AwAA', '1', '01f3024cefcea37f616197df66d18a3a');
INSERT INTO `flowsheet` VALUES ('2017-11-24', '75427', '1003', '20171124075426', '179.78.1.141', '0', 'OK', '83.04257', 'AAAAANTzXt61XgUAjgcAAAAAAACUAwAA', '1', '4df2908746fe8b8c68daa0feb69b3208');
INSERT INTO `flowsheet` VALUES ('2017-11-24', '173327', '1003', '20171124173323', '179.78.1.141', '0', 'OK', '80.62679', 'AAAAAG82DfW9XgUAjwcAAAAAAADaAwAA', '1', '4659dd92a591f5207f9db0cb32a1ddd9');
INSERT INTO `flowsheet` VALUES ('2017-11-24', '201534', '1170', '20171124201534', '179.78.1.31', '0', 'OK', '80.46222', 'AAAAACzh1TjAXgUAkAcAAAAAAADkAwAA', '1', 'c7fd486c9904d70191e9eb1a6a9d4d7a');
INSERT INTO `flowsheet` VALUES ('2017-11-27', '73700', '1306', '20171127073653', '179.77.1.1', '0', 'OK', '83.14622', 'AAAAAJFxbfnxXgUAlQcAAAAAAAARBAAA', '1', 'febb79ae31a2704385594a6340955b31');
INSERT INTO `flowsheet` VALUES ('2017-11-27', '75038', '1003', '20171127075037', '179.78.1.141', '0', 'OK', '79.10524', 'AAAAAJ+rLCryXgUAjgcAAAAAAAAjBAAA', '1', 'ce92de188db191045963b60b8ad7b674');
INSERT INTO `flowsheet` VALUES ('2017-11-27', '75419', '1170', '20171127075418', '179.78.1.31', '0', 'OK', '82.94967', 'AAAAAO9uXjfyXgUAjAcAAAAAAAAlBAAA', '1', 'f973d7029851c803e1ecd5f73c1f58d5');
INSERT INTO `flowsheet` VALUES ('2017-11-27', '141459', '1306', '20171127141453', '179.77.1.1', '0', 'OK', '80.94661', 'AAAAAJn2r4j3XgUAjgcAAAAAAAA1BAAA', '1', 'f2877cd685164353359e432eb2dc52fa');

-- ----------------------------
-- Table structure for mechanism
-- ----------------------------
DROP TABLE IF EXISTS `mechanism`;
CREATE TABLE `mechanism` (
  `mechid` varchar(4) NOT NULL COMMENT '机构号',
  `mechname` varchar(15) NOT NULL COMMENT '机构名',
  `mechip` varchar(16) NOT NULL COMMENT '机构ip',
  `minsimilarity` float(10,5) DEFAULT NULL,
  PRIMARY KEY (`mechid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mechanism
-- ----------------------------
INSERT INTO `mechanism` VALUES ('0001', 'A银行', '179.78.*.*', '75.00000');
INSERT INTO `mechanism` VALUES ('0002', 'B银行', '179.77.*.*', '75.00000');

-- ----------------------------
-- Table structure for runresult
-- ----------------------------
DROP TABLE IF EXISTS `runresult`;
CREATE TABLE `runresult` (
  `rundate` date NOT NULL,
  `runstate` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of runresult
-- ----------------------------
INSERT INTO `runresult` VALUES ('2017-11-30', '1');

-- ----------------------------
-- Table structure for specday
-- ----------------------------
DROP TABLE IF EXISTS `specday`;
CREATE TABLE `specday` (
  `specbdate` date NOT NULL COMMENT '开始日期',
  `specedate` date NOT NULL COMMENT '结束日期',
  `daytype` varchar(2) NOT NULL COMMENT '类型',
  `specname` varchar(10) DEFAULT NULL COMMENT '特殊名'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of specday
-- ----------------------------
INSERT INTO `specday` VALUES ('2017-09-30', '2017-09-30', 'W', '国庆节');
INSERT INTO `specday` VALUES ('2017-10-02', '2017-10-06', 'H', '国庆节');
INSERT INTO `specday` VALUES ('2017-10-07', '2017-11-07', 'W', '国庆节');
INSERT INTO `specday` VALUES ('2018-01-01', '2018-01-03', 'H', '元旦');
INSERT INTO `specday` VALUES ('2018-01-29', '2018-01-29', 'H', '春节');
INSERT INTO `specday` VALUES ('2018-01-30', '2018-01-31', 'W', '春节');
