/**
 * 
 */
package com.lzf.util;

/**
 * @author MJCoder
 *
 */
public class Test {

	/**
	 * 
	 */
	public Test() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(AipOpticalCharacterRecognition.aipOcrIdCard("G:/PHB/lpq.jpg").toString());
	}

}
